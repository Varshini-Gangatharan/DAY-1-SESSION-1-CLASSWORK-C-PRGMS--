/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int age,remage;
    printf("Enter the age: ");
    scanf("%d",&age);
    if(age<18)
    {
    printf("The person is not eligible for voting");
    remage=18-age;
    printf("\nyou have to wait for %d years",remage);
    }
    else if(age>=18)
    printf("The person is eligible for voting");
}

