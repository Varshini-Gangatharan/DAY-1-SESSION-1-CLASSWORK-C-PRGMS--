/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int reverse(int num);

int main()
{
    int num, rev;
    printf("Enter a number to reverse: ");
    scanf("%d", &num);
    rev = reverse(num);
    printf("Reversed number is: %d\n", rev);
    return 0;
}

int reverse(int num)
{
    int rev = 0, rem;
    while (num != 0) {
        rem = num % 10;
        rev = rev * 10 + rem;
        num /= 10;
    }
    return rev;
}

