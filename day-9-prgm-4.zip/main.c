/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <math.h>
int power(int x, int n) 
{
    return pow(x, n);
}
int addition(int x, int n) 
{
    return x + n;
}
int subtraction(int x, int n) 
{
    return x - n;
}
int multiplication(int x, int n) 
{
    return x * n;
}
int division(int x, int n) 
{
    return x / n;
}
int main() 
{
    int x, n, choice;
    int result;
    printf("Enter x and n: ");
    scanf("%d%d", &x, &n);
    printf("Enter operation to perform:\n");
    printf("1. Power\n");
    printf("2. Addition\n");
    printf("3. Subtraction\n");
    printf("4. Multiplication\n");
    printf("5. Division\n");
    printf("Enter your choice: ");
    scanf("%d", &choice);
    switch (choice) {
        case 1:
            result = power(x, n);
            printf("%d^%d = %d", x, n, result);
            break;
        case 2:
            result = addition(x, n);
            printf("%d + %d = %d", x, n, result);
            break;
        case 3:
            result = subtraction(x, n);
            printf("%d - %d = %d", x, n, result);
            break;
        case 4:
            result = multiplication(x, n);
            printf("%d * %d = %d", x, n, result);
            break;
        case 5:
            result = division(x, n);
            printf("%d / %d = %d", x, n, result);
            break;
        default:
            printf("Invalid choice!");
    }
    return 0;
}