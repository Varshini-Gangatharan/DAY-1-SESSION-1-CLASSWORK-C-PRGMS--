/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/
#include <stdio.h>
int main() 
{
    int p, q, r;
    printf("Enter the values of p, q and r: ");
    scanf("%d %d %d", &p, &q, &r);
    for (int i = p; i <= q; i++) 
    {
        int n = i;
        int flag = 0;
        while (n != 0) 
        {
            if (n % 10 == r) 
            {
                flag = 1;
                break;
            }
            n /= 10;
        }
        if (!flag) 
        {
            printf("%d ", i);
        }
    }
    return 0;
}
